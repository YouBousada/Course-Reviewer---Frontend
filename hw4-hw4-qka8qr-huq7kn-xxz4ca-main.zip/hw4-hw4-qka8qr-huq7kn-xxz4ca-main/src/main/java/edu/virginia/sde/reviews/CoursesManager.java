package edu.virginia.sde.reviews;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CoursesManager {
    private static CoursesManager instance;
    private static Connection conn;

    public CoursesManager() throws SQLException {
        if (conn == null || conn.isClosed()) {
            //CITATION: https://www.sqlitetutorial.net/sqlite-java/create-database/
            // Used to create and connect to the database.
            String url = "jdbc:sqlite:identifier.sqlite;foreign keys=true;";
            var conn = DriverManager.getConnection(url);

            //CITATION: https://www.sqlitetutorial.net/sqlite-java/create-table/
            // Used to create the Courses table.
            var sql = "CREATE TABLE IF NOT EXISTS Courses (" +
                    " CourseID INTEGER PRIMARY KEY," +
                    " Mnemonic TEXT NOT NULL," +
                    " Num INTEGER," +
                    " Title TEXT NOT NULL," +
                    " AverageRating REAL CHECK(AverageRating >= 0));";
            var stmt = conn.createStatement();
            stmt.execute("PRAGMA foreign_keys=ON;");
            stmt.execute(sql);
            conn.close();
        }
    }

    public static CoursesManager getInstance() throws SQLException {
        if (instance == null) {
            instance = new CoursesManager();
        }
        return instance;
    }


    public void addCourse(String mnemonic, int num, String title) throws SQLException {
        if (!( 2 <= mnemonic.length() && mnemonic.length() <= 4)){
            throw new IllegalArgumentException("Course mnemonic must be between 2 to 4 characters, inclusive. Please try again.");
        }
        //CITATION: https://stackoverflow.com/questions/1306727/way-to-get-number-of-digits-in-an-int
        // Used to get the number of digits for an integer.
        int numDigits = String.valueOf(num).length();
        if (numDigits != 4){
            throw new IllegalArgumentException("Course number must be exactly 4 digits. Please try again.");
        }
        if (!(!title.isEmpty() && title.length() <= 50)){
            throw new IllegalArgumentException("Course title must be between 1 to 50 characters, inclusive. Please try again.");
        }
        String url = "jdbc:sqlite:identifier.sqlite";
        var conn = DriverManager.getConnection(url);

        var sql = "INSERT INTO Courses(Mnemonic, Num, Title)"
                + " VALUES ('" + mnemonic + "', " + num + ", '" + title + "');";
        var stmt = conn.createStatement();
        stmt.execute("PRAGMA foreign_keys=ON;");
        stmt.execute(sql);
        System.out.println("AddCourse() ran.");
        conn.close();
    }

    public ResultSet getTable() throws SQLException {
        String url = "jdbc:sqlite:identifier.sqlite";
        var conn = DriverManager.getConnection(url);
        var sql = " SELECT * FROM Courses;";
        var stmt = conn.createStatement();
        stmt.execute("PRAGMA foreign_keys=ON;");
        conn.close();
        return stmt.executeQuery(sql);
    }

    public ResultSet searchCoursesMnemonic(String mnemonic) throws SQLException {
        String url = "jdbc:sqlite:identifier.sqlite";
        var conn = DriverManager.getConnection(url);
        var sql = "SELECT * FROM Courses"
                + " WHERE Mnemonic == '" + mnemonic + "';";
        var stmt = conn.createStatement();
        stmt.execute("PRAGMA foreign_keys=ON;");
        var x = stmt.executeQuery(sql);
        conn.close();
        return x;
    }

    public ResultSet searchCoursesNum(int num) throws SQLException {
        String url = "jdbc:sqlite:identifier.sqlite";
        var conn = DriverManager.getConnection(url);
        var sql = "SELECT * FROM Courses"
                + " WHERE Num == '" + num + "';";
        var stmt = conn.createStatement();
        stmt.execute("PRAGMA foreign_keys=ON;");
        var x = stmt.executeQuery(sql);
        conn.close();
        return x;
    }

    public ResultSet searchCoursesTitle(String title) throws SQLException {
        String url = "jdbc:sqlite:identifier.sqlite";
        var conn = DriverManager.getConnection(url);
        var sql = "SELECT * FROM Courses"
                + " WHERE Title LIKE '" + title + "';";
        var stmt = conn.createStatement();
        stmt.execute("PRAGMA foreign_keys=ON;");
        var x = stmt.executeQuery(sql);
        conn.close();
        return x;
    }
    public String[][] getCoursesAsArray() throws SQLException {
        ResultSet resultSet = getTable();
        int numberOfRows = 0;
        while (resultSet.next()) {
            numberOfRows++;
        }
        resultSet = getTable();
        String[][] info = new String[numberOfRows][3];
        int index = 0;
        while (resultSet.next()) {
            info[index][0] = resultSet.getString("Mnemonic");
            info[index][1] = String.valueOf(resultSet.getInt("Num"));
            info[index][2] = resultSet.getString("Title");
            index++;
        }
        return info;
    }
}