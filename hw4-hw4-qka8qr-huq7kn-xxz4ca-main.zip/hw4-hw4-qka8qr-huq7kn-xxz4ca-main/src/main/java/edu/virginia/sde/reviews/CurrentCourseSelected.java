package edu.virginia.sde.reviews;

import java.sql.SQLException;

public class CurrentCourseSelected {
    private String className;
    private String subject;
    private int number;
    private static String[][] reviews;
    private static CurrentCourseSelected instance;

    public void setCourse(Course course) throws SQLException {
        this.className = course.getTitle();
        this.subject = course.getSubject();
        this.number = course.getNumber();
//        SqlParser parser = new SqlParser();
//        reviews = parser.getCourseSpecificReviewsAsArray(this.number);
    }

    public CurrentCourseSelected() throws SQLException {}

    public static CurrentCourseSelected getInstance() throws SQLException {
        if (instance == null) {
            instance = new CurrentCourseSelected();
        }
        return instance;
    }

    public String getClassName() {
        return className;
    }

    public String getSubject() {
        return subject;
    }

    public int getNumber() {
        return number;
    }


    public void setClassName(String className) {
        this.className = className;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}
