package edu.virginia.sde.reviews;

public class Course {

    private final String subject;
    private final int number;
    private final String title;
    private final Double averageRating;

    public Course(String subject, int number, String title, Double averageRating) {
        this.subject = subject;
        this.number = number;
        this.title = title;
        this.averageRating = averageRating;
    }

    public String getSubject() { return subject; }
    public int getNumber() { return number; }
    public String getTitle() { return title; }
    public Double getAverageRating() { return averageRating; }

    public boolean hasReviews() {
        return averageRating != null;
    }
}
