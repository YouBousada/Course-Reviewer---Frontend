package edu.virginia.sde.reviews;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.sql.SQLException;

public class UsernamePasswordValidator {

    LoginManager loginManager = LoginManager.getInstance();

    public boolean usernameIsValid;
    public boolean passwordIsValid;

    public UsernamePasswordValidator() throws SQLException {
        this.usernameIsValid = false;
        this.passwordIsValid = false;
    }

    public void validate(TextField field, Label errorLabel, String type, boolean applyStyles) throws SQLException {
        String userNameOrPassword = field.getText();

        if (type.equals("username")) {
            if (userNameOrPassword == null || userNameOrPassword.isEmpty()) {
                usernameIsValid = false;
                errorLabel.setText("Username cannot be empty");
                errorLabel.setVisible(true);
                if (applyStyles) field.getStyleClass().add("textfield-error");
            } else if (loginManager.userExists(userNameOrPassword)) {
                usernameIsValid = false;
                errorLabel.setText("Username already in use");
                errorLabel.setVisible(true);
                if (applyStyles) field.getStyleClass().add("textfield-error");
            } else {
                usernameIsValid = true;
                errorLabel.setVisible(false);
                field.getStyleClass().remove("textfield-error");
            }
        }

        if (type.equals("password")) {
            if (userNameOrPassword == null || userNameOrPassword.length() < 8) {
                passwordIsValid = false;
                errorLabel.setText("Password must be at least 8 characters");
                errorLabel.setVisible(true);
                if (applyStyles) field.getStyleClass().add("textfield-error");
            } else {
                passwordIsValid = true;
                errorLabel.setVisible(false);
                field.getStyleClass().remove("textfield-error");
            }
        }
    }

    public String CanSignUp() {
        if (usernameIsValid && passwordIsValid) {
            return "Successfully created account!";
        } else {
            return "Cannot create account, invalid field(s) above";
        }
    }
}