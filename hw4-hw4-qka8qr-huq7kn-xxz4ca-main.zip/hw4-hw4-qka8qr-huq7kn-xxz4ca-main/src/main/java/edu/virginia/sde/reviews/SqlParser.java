package edu.virginia.sde.reviews;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SqlParser {
    private final Connection conn;
    private static SqlParser instance;
    private final CoursesManager coursesManager;
    private final ReviewsManager reviewsManager;

    public SqlParser() throws SQLException {
        String url = "jdbc:sqlite:identifier.sqlite";
        conn = DriverManager.getConnection(url);
        coursesManager = CoursesManager.getInstance();
        reviewsManager = ReviewsManager.getInstance();

    }

    public String[][] getCoursesAsArray() throws SQLException {
        ResultSet table = coursesManager.getTable();
        List<String[]> rows = new ArrayList<>();

        while (table.next()) {
            String[] row = new String[3];
            row[0] = table.getString("Mnemonic");
            row[1] = String.valueOf(table.getInt("Num"));
            row[2] = table.getString("Title");
            rows.add(row);
        }

        return rows.toArray(new String[0][0]);
    }

    public String [][] getCourseSpecificReviewsAsArray(int number) throws SQLException{
        ResultSet table = reviewsManager.getTable(number);

        int numberOfRows = 0;
        while (table.next()) {
            numberOfRows++;
        }
        String[][] info = new String[numberOfRows][5];
        int index = 0;
        while (table.next()) {
            info[index][0] = table.getString("Username");
            info[index][1] = String.valueOf(table.getInt("Num"));
            try{
                info[index][2] = table.getString("Comment");
            }
            catch(SQLException e){
                info[index][2] = "";
            }
            info[index][3] = String.valueOf(table.getInt("Rating"));
            info[index][4] = table.getString("TimeOfReview");

            index++;
        }
        return info;
    }
}
