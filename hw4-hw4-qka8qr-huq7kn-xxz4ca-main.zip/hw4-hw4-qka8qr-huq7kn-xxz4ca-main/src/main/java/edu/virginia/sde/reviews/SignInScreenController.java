package edu.virginia.sde.reviews;
import java.sql.SQLException;

public class SignInScreenController extends AuthFormController {


    @Override
    public void initialize() {
        javafx.application.Platform.runLater(() -> userNameFeild.requestFocus());

        userNameErrorLabel.setVisible(false);
        passwordErrorLabel.setVisible(false);
        SignMessageLabel.setVisible(false);

        SignButton.setOnAction(event -> {
            try {
                handleAuthAction();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });
        Signlink.setOnAction(event -> handleSignLink());
    }

    @Override
    protected void handleAuthAction() throws SQLException {

        String username = userNameFeild.getText();
        String password = passwordFeild.getText();

        LoginManager loginManager = LoginManager.getInstance();

        if (loginManager.login(username, password)) {

            SignMessageLabel.setText("Successfully signed in!");
            SignMessageLabel.getStyleClass().setAll("sign-success");
            CurrentUser.login(username);
            SceneSwitcher.switchTo(Scene.COURSE_SEARCH);
        }

        else {

            if(loginManager.userExists(username)){SignMessageLabel.setText("Incorrect password");}

            else{SignMessageLabel.setText("User not found in database");}

            SignMessageLabel.getStyleClass().setAll("sign-error");
        }

        SignMessageLabel.setVisible(true);
    }

    @Override
    protected void handleSignLink() {
        SceneSwitcher.switchTo(Scene.SIGN_UP);
    }
}
