package edu.virginia.sde.reviews;
//


import java.sql.Timestamp;

public class reviewModel {
    private String username;
    private int rating;
    private String comments;
    private Timestamp timestamp; //Cite for ref - Timestamp https://docs.oracle.com/javase/8/docs/api/java/sql/Timestamp.html

    public reviewModel(String username, int rating, String comments, Timestamp timestamp) {
        this.username = username;
        this.rating = rating;
        this.comments = comments;
        this.timestamp = timestamp;
    }
    public String getUsername() {
        return username;
    }
    public int getRating() {
        return rating;
    }
    public String getComments() {
        return comments;
    }
    public Timestamp getTimestamp() {
        return timestamp;
    }

}
