package edu.virginia.sde.reviews;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginManager {
    private static LoginManager instance;
    private static Connection conn;

    LoginManager() throws SQLException {
        if (conn == null || conn.isClosed()) {
            String url = "jdbc:sqlite:identifier.sqlite;foreign keys=true;";
            conn = DriverManager.getConnection(url);
            var stmt = conn.createStatement();
            stmt.execute("PRAGMA foreign_keys=ON;");
            stmt.execute("CREATE TABLE IF NOT EXISTS Users (Username TEXT NOT NULL UNIQUE, Password TEXT NOT NULL) STRICT;");
            conn.close();
        }
    }

    public static LoginManager getInstance() throws SQLException {
        if (instance == null) {
            instance = new LoginManager();
        }
        return instance;
    }

    public void addUser(String user, String pass) throws SQLException {
        String url = "jdbc:sqlite:identifier.sqlite";
        var conn = DriverManager.getConnection(url);
        var stmt = conn.createStatement();
        String sql = "SELECT username FROM Users WHERE Username = '" + user + "';";
        ResultSet rs = stmt.executeQuery(sql);

        if (rs.next()) {
            throw new IllegalArgumentException("This username is already taken. Please try again with a unique username.");
        }

        if (pass.length() < 8) {
            throw new IllegalArgumentException("This password is below 8 characters. Please try again with a password at least 8 characters.");
        }

        sql = "INSERT INTO Users (username, password) VALUES ('" + user + "', '" + pass + "');";
        stmt.executeUpdate(sql);
        conn.close();
    }

    public boolean login(String user, String pass) throws SQLException {
        String url = "jdbc:sqlite:identifier.sqlite";
        var conn = DriverManager.getConnection(url);
        String sql = "SELECT username, password FROM Users WHERE Username = '" + user + "' AND Password = '" + pass + "';";
        var stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        var x = rs.next();
        conn.close();
        return x;
    }

    public boolean userExists(String user) throws SQLException {
        String url = "jdbc:sqlite:identifier.sqlite";
        var conn = DriverManager.getConnection(url);
        String sql = "SELECT username FROM Users WHERE Username = '" + user + "';";
        var stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        var x = rs.next();
        conn.close();
        return x;
    }
}
