package edu.virginia.sde.reviews;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.sql.SQLException;

public abstract class AuthFormController {
    @FXML protected TextField userNameFeild;
    @FXML protected Label userNameErrorLabel;
    @FXML protected PasswordField passwordFeild;
    @FXML protected Label passwordErrorLabel;
    @FXML protected Label SignMessageLabel;
    @FXML protected Button SignButton;
    @FXML protected Hyperlink Signlink;

    protected UsernamePasswordValidator validator;

    @FXML
    public void initialize() throws SQLException {
        validator = new UsernamePasswordValidator();

        userNameErrorLabel.setVisible(false);
        passwordErrorLabel.setVisible(false);
        SignMessageLabel.setVisible(false);

        javafx.application.Platform.runLater(() -> userNameFeild.requestFocus());

        userNameFeild.textProperty().addListener((obs, oldVal, newVal) ->
                {
                    try {
                        validator.validate(userNameFeild, userNameErrorLabel, "username", false);
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                }
        );

        passwordFeild.textProperty().addListener((obs, oldVal, newVal) ->
                {
                    try {
                        validator.validate(passwordFeild, passwordErrorLabel, "password", false);
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                }
        );

        userNameFeild.focusedProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal){
                userNameFeild.getStyleClass().remove("textfield-error");
                userNameFeild.getStyleClass().add("textFeild:focused");
            }
        });

        passwordFeild.focusedProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal){
                passwordFeild.getStyleClass().remove("textfield-error");
            }

        });

        SignButton.setOnAction(event -> {
            try {
                handleAuthAction();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });

        Signlink.setOnAction(event -> handleSignLink());

    }

    protected abstract void handleAuthAction() throws SQLException;
    protected abstract void handleSignLink();
}
