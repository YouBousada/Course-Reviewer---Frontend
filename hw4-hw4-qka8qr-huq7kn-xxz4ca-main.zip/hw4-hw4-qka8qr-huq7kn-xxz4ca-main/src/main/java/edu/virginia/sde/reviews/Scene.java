package edu.virginia.sde.reviews;

public enum Scene {
    SIGN_IN("/edu/virginia/sde/reviews/SignIn.fxml"),
    SIGN_UP("/edu/virginia/sde/reviews/SignUp.fxml"),
    CREATE_COURSE("/edu/virginia/sde/reviews/CreateCourse.fxml"),
    MY_REVIEWS("/edu/virginia/sde/reviews/MyReviews.fxml"),
    COURSE_SEARCH("/edu/virginia/sde/reviews/CourseSearch.fxml"),
    COURSE_REVIEWS("/edu/virginia/sde/reviews/courseReviews.fxml");

    private final String path;

    Scene(String path) {
        this.path = path;
    }

    public String getPath() {
        return path;
    }
}