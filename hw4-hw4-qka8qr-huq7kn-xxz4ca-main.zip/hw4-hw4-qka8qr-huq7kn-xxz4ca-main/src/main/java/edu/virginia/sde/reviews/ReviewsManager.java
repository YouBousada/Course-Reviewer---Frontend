package edu.virginia.sde.reviews;

import org.sqlite.SQLiteConfig;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class ReviewsManager {
    private Connection conn;
    private static ReviewsManager instance;

    public ReviewsManager() throws SQLException {
        LoginManager login = new LoginManager();
        CoursesManager courses = new CoursesManager();

        String url = "jdbc:sqlite:identifier.sqlite;foreign keys=true;";
        //conn = DriverManager.getConnection(url);
        SQLiteConfig config = new SQLiteConfig();
        config.enforceForeignKeys(true);
        conn = DriverManager.getConnection("jdbc:sqlite:identifier.sqlite",config.toProperties());
        var stmt = conn.createStatement();
        stmt.execute("PRAGMA foreign_keys=ON;");
        String createReviews = """
                CREATE TABLE IF NOT EXISTS Reviews (
                    ReviewID INTEGER PRIMARY KEY,
                    Username TEXT NOT NULL,
                    Num INTEGER NOT NULL,
                    Title TEXT NOT NULL,
                    Mnemonic TEXT NOT NULL,
                    Rating INTEGER,
                    Comment TEXT DEFAULT '',
                    TimeOfReview TEXT NOT NULL,
                    FOREIGN KEY (Username) REFERENCES Courses(Username)
                        ON DELETE CASCADE ON UPDATE CASCADE
                    FOREIGN KEY (Num) REFERENCES Courses(Num)
                        ON DELETE CASCADE ON UPDATE CASCADE
                    FOREIGN KEY (Title) REFERENCES Courses(Title)
                        ON DELETE CASCADE ON UPDATE CASCADE
                );
            """;
        stmt.execute(createReviews);
        conn.close();
    }

    public static ReviewsManager getInstance() throws SQLException {
        if (instance == null) {
            instance = new ReviewsManager();
        }
        return instance;
    }

    //TODO: prevent adding multiple reviews
    public void addWithoutComment(String user, int courseNum, int rating) throws SQLException {
        String url = "jdbc:sqlite:identifier.sqlite";
        conn = DriverManager.getConnection(url);
        String formattedTime = getTime();
        var stmt = conn.createStatement();
        stmt.execute("PRAGMA foreign_keys=ON;");
        String sql = """
                INSERT INTO Reviews(Username, Num, Rating, TimeOfReview)
                    VALUES ('%s', %d, %d,  '%s');
                """.formatted(user, courseNum, rating, formattedTime);
        //stmt.execute("INSERT INTO Reviews(Username, Num, Rating, TimeOfReview)"
        //        + " VALUES ('" + user + "', " + courseNum + ", " + rating + ", '" + formattedTime + "');");
        stmt.execute(sql);
        conn.close();
    }

    public void addWithComment(String user, int courseNum, int rating, String comment, String mnemonic, String title) throws SQLException {
        String url = "jdbc:sqlite:identifier.sqlite";
        conn = DriverManager.getConnection(url);
        String formattedTime = getTime();
        var stmt = conn.createStatement();
        stmt.execute("PRAGMA foreign_keys=ON;");
        stmt.execute("""
                INSERT INTO Reviews(Username, Num, Rating, TimeOfReview, Comment, Title, Mnemonic) VALUES ('%s', %d, %d, '%s', '%s', '%s', '%s');""".formatted(user, courseNum, rating, formattedTime, comment, mnemonic, title));
        conn.close();
    }

    public void updateReview(String user, int courseNum, int rating, String comment, String mnemonic, String title) throws SQLException {
        String url = "jdbc:sqlite:identifier.sqlite";
        conn = DriverManager.getConnection(url);
        String formattedTime = getTime();
        var stmt = conn.createStatement();
        stmt.execute("PRAGMA foreign_keys=ON;");
        String sql = String.format(
                "UPDATE Reviews SET Rating = %d, Comment = '%s' WHERE Username = '%s' AND Num = %d;",
                rating, comment, user, courseNum);
        stmt.execute(sql);
        conn.close();
    }

    public void deleteReview(String user, int courseNum) throws SQLException{
        String url = "jdbc:sqlite:identifier.sqlite";
        conn = DriverManager.getConnection(url);
        var stmt = conn.createStatement();
        stmt.execute("PRAGMA foreign_keys=ON;");
        String sql = "DELETE from Reviews"
                + " WHERE Username = '%s'".formatted(user)
                + " AND Num = '%d'".formatted(courseNum);
        stmt.execute(sql);
        conn.close();
    }

    public void searchReviewsByUser(String user) throws SQLException {
        String url = "jdbc:sqlite:identifier.sqlite";
        conn = DriverManager.getConnection(url);
        var stmt = conn.createStatement();
        stmt.execute("PRAGMA foreign_keys=ON;");
        String sql = "SELECT * FROM Reviews"
                + " WHERE Username = '%s';".formatted(user);
        stmt.execute(sql);
        conn.close();
    }

    public ResultSet getTable() throws SQLException {
        String url = "jdbc:sqlite:identifier.sqlite";
        conn = DriverManager.getConnection(url);
        var sql = " SELECT * FROM Reviews;";
        var stmt = conn.createStatement();
        stmt.execute("PRAGMA foreign_keys=ON;");
        var x = stmt.executeQuery(sql);
        conn.close();
        return x;
    }

    public ResultSet getTable(int number) throws SQLException{
        String url = "jdbc:sqlite:identifier.sqlite";
        conn = DriverManager.getConnection(url);
        var sql = "PRAGMA foreign_keys=ON; SELECT * FROM Reviews"
                + " WHERE Num = ''%d".formatted(number);
        var stmt = conn.createStatement();
        stmt.execute("PRAGMA foreign_keys=ON;");
        var x = stmt.executeQuery(sql);
        conn.close();
        return x;
    }

    private static String getTime() {
        //CITATION: https://stackoverflow.com/questions/23068676/how-to-get-current-timestamp-in-string-format-in-java-yyyy-mm-dd-hh-mm-ss
        // Used to get the current time which will be added to the course review
        LocalDateTime currentTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return currentTime.format(formatter);
    }

    public List<reviewModel> getReviewsUsername(String username) throws SQLException {
        String url = "jdbc:sqlite:identifier.sqlite";
        conn = DriverManager.getConnection(url);

        List<reviewModel> theReviews = new ArrayList<>();

        String sql = "SELECT Rating, Comment, TimeOfReview FROM Reviews WHERE Username = ?";
        //Cite PreparedStatement use: https://www.geeksforgeeks.org/java/how-to-use-preparedstatement-in-java/
        PreparedStatement preparedStatement = conn.prepareStatement(sql);
        preparedStatement.execute("PRAGMA foreign_keys=ON;");
        preparedStatement.setString(1, username);
        ResultSet resultSet = preparedStatement.executeQuery();

        while (resultSet.next()) {
            int rating = resultSet.getInt("Rating");
            String comment = resultSet.getString("Comment");
            Timestamp timestamp = Timestamp.valueOf(resultSet.getString("TimeOfReview"));

            reviewModel review = new reviewModel(username, rating, comment, timestamp);
            theReviews.add(review);
        }
        conn.close();
        return theReviews;
    }
}