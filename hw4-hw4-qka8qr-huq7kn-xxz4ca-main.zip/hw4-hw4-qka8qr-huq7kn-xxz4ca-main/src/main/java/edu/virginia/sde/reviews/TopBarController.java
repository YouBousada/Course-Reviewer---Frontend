package edu.virginia.sde.reviews;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class TopBarController {
    @FXML
    private SplitMenuButton accountNameLabel;
    @FXML
    private Button logoutButton;
    @FXML
    private Button exitButton;

    @FXML
    private MenuItem myReviewedCourses;
    @FXML
    private MenuItem allCourses;
    @FXML
    private MenuItem addCourse;


    private static TopBarController instance;

    public TopBarController() {
        instance = this;
    }

    public static TopBarController getInstance() {
        return instance;
    }

    private void hideUserInfo() {
        accountNameLabel.setVisible(false);
        logoutButton.setVisible(false);
    }

    private void showUserInfo() {
        accountNameLabel.setVisible(true);
        logoutButton.setVisible(true);
    }

    @FXML
    public void initialize() {
        hideUserInfo();
        accountNameLabel.setText(CurrentUser.getUsername());
        exitButton.setOnAction(e -> System.exit(0));

        logoutButton.setOnAction(logOut -> {
            CurrentUser.reset();
            SceneSwitcher.switchTo(Scene.SIGN_IN);
            hideUserInfo();
        });

        accountNameLabel.setOnAction(e -> {
            accountNameLabel.show();
        });
        accountNameLabel.setOnHidden(event -> {
            accountNameLabel.getParent().requestFocus();
        });

        myReviewedCourses.setOnAction(e -> {
            SceneSwitcher.switchTo(Scene.MY_REVIEWS);
        });
        allCourses.setOnAction(e -> {
            SceneSwitcher.switchTo(Scene.COURSE_SEARCH);
        });
        addCourse.setOnAction(e -> {
            SceneSwitcher.switchTo(Scene.CREATE_COURSE);
        });
    }

    public void login() {
        accountNameLabel.setText(CurrentUser.getUsername());
        showUserInfo();
        Platform.runLater(() -> accountNameLabel.requestFocus());
    }
}