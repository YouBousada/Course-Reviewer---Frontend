package edu.virginia.sde.reviews;

import java.sql.SQLException;

public class SignUpsScreenController extends AuthFormController {

    @Override
    protected void handleAuthAction() throws SQLException {
        LoginManager logginManager = LoginManager.getInstance();

        String username = userNameFeild.getText();
        String password = passwordFeild.getText();

        validator.validate(userNameFeild, userNameErrorLabel, "username", true);
        validator.validate(passwordFeild, passwordErrorLabel, "password", true);

        String result = validator.CanSignUp();
        SignMessageLabel.setText(result);
        SignMessageLabel.setVisible(true);

        if (result.startsWith("Successfully")) {
            SignMessageLabel.getStyleClass().removeAll("sign-error");
            if (!SignMessageLabel.getStyleClass().contains("sign-success"))
                SignMessageLabel.getStyleClass().add("sign-success");
            logginManager.addUser(username, password);
        } else {
            SignMessageLabel.getStyleClass().removeAll("sign-success");
            if (!SignMessageLabel.getStyleClass().contains("sign-error"))
                SignMessageLabel.getStyleClass().add("sign-error");
        }
    }
    @Override
    protected void handleSignLink() {
        SceneSwitcher.switchTo(Scene.SIGN_IN);
    }
}
