package edu.virginia.sde.reviews;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.sql.SQLException;

public class CourseBoxController {
    @FXML private Label subjectLabel;
    @FXML private Label numberLabel;
    @FXML private Label titleLabel;
    @FXML private Label ratingLabel;

    private Course course;

    public void setCourse(Course course) {
        this.course = course;
        subjectLabel.setText(course.getSubject());
        numberLabel.setText(String.valueOf(course.getNumber()));
        titleLabel.setText(course.getTitle());
        ratingLabel.setText(course.hasReviews() ? String.format("Rating: %.2f", course.getAverageRating()) : "");
    }

    @FXML
    private void handleClick() throws SQLException {
        System.out.println("Course clicked: " + course.getTitle());
        CurrentCourseSelected currCourse = CurrentCourseSelected.getInstance();
        currCourse.setCourse(course);
        SceneSwitcher.switchTo(Scene.COURSE_REVIEWS);
    }
}
