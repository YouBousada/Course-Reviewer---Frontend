package edu.virginia.sde.reviews;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

public class ReviewBoxController {

    @FXML private Label subjectLabel;
    @FXML private Label numberLabel;
    @FXML private Label ratingLabel;
    @FXML private Label commentLabel;
    @FXML private Label timeLabel;
    @FXML private HBox courseInfoBox;

    public void setReviewData(Review review) {
        subjectLabel.setText(review.getSubject());
        numberLabel.setText(String.valueOf(review.getNumber()));
        ratingLabel.setText(String.format("Rating: %.1f", review.getRating()));
        commentLabel.setText(review.getComment());
        timeLabel.setText(review.getTimePosted());
    }

    public void setReviewData(Review review, boolean hideCourseInfo) {
        subjectLabel.setText(review.getSubject());
        numberLabel.setText(String.valueOf(review.getNumber()));
        ratingLabel.setText(String.format("Rating: %.1f", review.getRating()));
        commentLabel.setText(review.getComment());
        timeLabel.setText(review.getTimePosted());

        if (hideCourseInfo) {
            courseInfoBox.setVisible(false);
            courseInfoBox.setManaged(false); // removes spacing
        }
    }
}