package edu.virginia.sde.reviews;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class CourseReviewsController {

    @FXML private Label lblCourseFullName;
    @FXML private Label lblCourseRating;
    @FXML private Hyperlink returnToCourseSearch;
    @FXML private Button createReview;
    @FXML private Button deleteReview;
    @FXML private Label message;
    @FXML private TextField numericalRating;
    @FXML private ScrollPane reviewsContainer;
    @FXML private Label reviewCountLabel;

    public void initialize() throws SQLException {
        // Load course info
        CurrentCourseSelected thisCourse = CurrentCourseSelected.getInstance();
        lblCourseFullName.setText(thisCourse.getSubject() + " " + thisCourse.getNumber() + ": " + thisCourse.getClassName());
        lblCourseRating.setText("Overall Course Rating: " + "4.95" + " / 5");

        returnToCourseSearch.setOnAction(event -> SceneSwitcher.switchTo(Scene.COURSE_SEARCH));

        deleteReview.setOnAction(event -> {
            // TODO: implement
        });

        createReview.setOnAction(event -> {
            message.getStyleClass().removeAll("sign-success", "sign-error");
            if (isValidRating(numericalRating.getText())) {
                message.setText("Course Review Created Successfully");
                message.getStyleClass().add("sign-success");
            } else {
                message.setText("Cannot submit review, please add valid rating");
                message.getStyleClass().add("sign-error");
            }
            message.setVisible(true);
        });

        //TODO: Dummy reviews
        List<Review> dummyCourseReviews = List.of(
                new Review("CS", 1110, 4.5, "One of the best lectures I've attended!", "2024-12-10"),
                new Review("CS", 1110, 3.8, "Interesting content but fast-paced.", "2025-01-15"),
                new Review("CS", 1110, 5.0, "Truly outstanding!", "2025-03-05")
        );

        reviewCountLabel.setText(dummyCourseReviews.size() + " Reviews");

        // Create and populate VBox
        VBox contentBox = new VBox();
        contentBox.setSpacing(12);
        contentBox.setPadding(new Insets(16));
        contentBox.setFillWidth(true);

        for (Review review : dummyCourseReviews) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("ReviewBox.fxml"));
                HBox reviewBox = loader.load();
                ReviewBoxController controller = loader.getController();
                controller.setReviewData(review, true); // hide subject and number
                contentBox.getChildren().add(reviewBox);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        reviewsContainer.setContent(contentBox);
    }

    public static boolean isValidRating(String input) {
        if (input == null) {
            return false;
        }
        try {
            int rating = Integer.parseInt(input.trim());
            return rating >= 1 && rating <= 5;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
