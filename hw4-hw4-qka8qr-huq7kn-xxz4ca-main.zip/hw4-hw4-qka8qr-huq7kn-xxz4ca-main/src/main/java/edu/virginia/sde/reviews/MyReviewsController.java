package edu.virginia.sde.reviews;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class MyReviewsController {

    @FXML private VBox reviewsContainer;
    @FXML private Label TheReviewsTitle;

    @FXML
    private void initialize() {
        TheReviewsTitle.setText(CurrentUser.getUsername() + "'s Reviews");

        //TODO: Mock reviews, replace with actual reviews
        List<Review> mockReviews = List.of(
                new Review("CS", 1110, 4.5, "This class was very insightful!", "2024-12-10"),
                new Review("MATH", 3100, 3.2, "Tough grader but learned a lot.", "2025-01-15"),
                new Review("PHYS", 2415, 5.0, "Loved every second of it!", "2025-03-05")
        );

        for (Review review : mockReviews) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("ReviewBox.fxml"));
                HBox reviewBox = loader.load();
                ReviewBoxController controller = loader.getController();
                controller.setReviewData(review);
                reviewsContainer.getChildren().add(reviewBox);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}