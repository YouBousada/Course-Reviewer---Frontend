package edu.virginia.sde.reviews;

public class CurrentUser {

    private static String username = null;
    private static boolean login = false;


    public static String getUsername() {
        return username;
    }
    public static boolean isLoggedIn() {
        return login;
    }
    public static void reset(){
        username = null;
        login = false;
    }
    public static void login(String newName){
        login = true;
        username = newName;
        TopBarController.getInstance().login();
    }

}
