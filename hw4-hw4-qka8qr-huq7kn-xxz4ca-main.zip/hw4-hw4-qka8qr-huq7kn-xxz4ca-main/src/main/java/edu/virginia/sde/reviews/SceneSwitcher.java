package edu.virginia.sde.reviews;

public class SceneSwitcher {

    private static Scene currentScene = Scene.SIGN_IN;

    public static void switchTo(Scene scene) {
        MainLayoutController.getInstance().setContent(scene.getPath());
        currentScene = scene;
    }

    public static String getCurrentScenePath() {
        return currentScene.getPath();
    }
}