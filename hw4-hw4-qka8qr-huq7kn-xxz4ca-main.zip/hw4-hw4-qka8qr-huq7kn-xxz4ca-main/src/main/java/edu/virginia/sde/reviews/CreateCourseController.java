package edu.virginia.sde.reviews;

import javafx.fxml.FXML;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.sql.SQLException;


public class CreateCourseController {
    @FXML
    private TextField courseName;
    @FXML
    private TextField courseSubject;
    @FXML
    private TextField courseNumber;

    @FXML private Label courseNameMessage;
    @FXML private Label courseNumberMessage;
    @FXML private Label courseSubjectMessage;
    @FXML private Label finalMessage;

    @FXML private Button createCourseButton;


    public void initialize() {

        courseName.setVisible(true);
        courseSubject.setVisible(true);
        courseNumber.setVisible(true);
        finalMessage.setVisible(false);

        courseNameMessage.setVisible(false);
        courseSubjectMessage.setVisible(false);
        courseNumberMessage.setVisible(false);

        createCourseButton.setOnAction(event -> {
            NewCourseValidator newCourseValidator = new NewCourseValidator(courseName.getText(), courseSubject.getText(), courseNumber.getText());

            if(newCourseValidator.courseNumberIsLegal() && !newCourseValidator.classExists()) {
                courseNumberMessage.setVisible(false);
            }
            else{
                courseNumberMessage.setText(newCourseValidator.getReasonForCourseNumberError());
                courseNumberMessage.setVisible(true);
            }

            if(newCourseValidator.courseNameIsLegal() && !newCourseValidator.classExists()){
                courseNameMessage.setVisible(false);
            }
            else{
                courseNameMessage.setText(newCourseValidator.getReasonForCourseNameError());
                courseNameMessage.setVisible(true);
            }

            if(newCourseValidator.courseSubjectIsLegal() && !newCourseValidator.classExists()){
                courseSubjectMessage.setVisible(false);
            }
            else{
                courseSubjectMessage.setText(newCourseValidator.getReasonForSubjectError());
                courseSubjectMessage.setVisible(true);
            }
            finalMessage.getStyleClass().removeAll("sign-success", "sign-error");

            if(newCourseValidator.canCreateCourse()){
                try {
                    newCourseValidator.createCourse();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                finalMessage.setText("Course successfully created!");
                finalMessage.getStyleClass().add("sign-success");
            }
            else{
                finalMessage.setText("Cannot create course, please fix invalid field(s)");
                finalMessage.getStyleClass().add("sign-error");
            }

            finalMessage.setVisible(true);
        });
    }

}
