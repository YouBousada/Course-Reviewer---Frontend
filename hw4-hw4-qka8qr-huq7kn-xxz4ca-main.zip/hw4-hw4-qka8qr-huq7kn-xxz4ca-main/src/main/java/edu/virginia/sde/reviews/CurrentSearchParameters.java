package edu.virginia.sde.reviews;

public class CurrentSearchParameters {
    private String courseName;
    private String courseNumber;
    private String courseSubject;

    public CurrentSearchParameters(String courseName, String courseNumber, String courseSubject) {
        this.courseName = courseName;
        this.courseNumber = courseNumber;
        this.courseSubject = courseSubject;
    }

    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }

    public String getCourseNumber() { return courseNumber; }
    public void setCourseNumber(String courseNumber) { this.courseNumber = courseNumber; }

    public String getCourseSubject() { return courseSubject; }
    public void setCourseSubject(String courseSubject) { this.courseSubject = courseSubject; }
}