package edu.virginia.sde.reviews;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;


public class NewCourseValidator {
    public String courseName;
    public String courseSubject;
    public String courseNumber;

    public HashSet names = new HashSet();
    public HashSet subjects = new HashSet();
    public HashSet numbers = new HashSet();


    public NewCourseValidator(String courseName, String courseSubject, String courseNumber) {
        this.courseName = courseName;
        this.courseSubject = courseSubject;
        this.courseNumber = courseNumber;
    }

    public boolean courseNameIsLegal(){
        if(courseName.isEmpty()){return false;}
        if(courseName.length() <= 50){return true;}
        return false;
    }

    public boolean courseSubjectIsLegal(){
        if(courseSubject.isEmpty()){return false;}
        if(courseSubject.length() > 4 || courseSubject.length() < 2){return false;}
        char[] chars = courseSubject.toCharArray();
        for (char c : chars) {
            if(!Character.isLetter(c)) {
                return false;
            }
        }
        return true;
    }

    public boolean everyThingIsLegal(){
        return courseNameIsLegal() && courseSubjectIsLegal() && courseNumberIsLegal();
    }

    public boolean courseNumberIsLegal(){
        if(courseNumber.isEmpty()){return false;}
        if(courseNumber.length() > 4){return false;}
        try {
            Integer.parseInt(courseNumber);
            return true;
            }
        catch(NumberFormatException e){
            return false;
        }
    }

    private boolean courseNameIsTaken(){
        return (names.contains(courseName));
    }

    private boolean subjectIsTaken(){
        return (subjects.contains(courseSubject));
    }
    private boolean numberIsTaken(){
        return (numbers.contains(courseNumber));
    }

   public boolean classExists(){
        return courseNameIsTaken() && subjectIsTaken() && numberIsTaken();
    }

    public String getReasonForCourseNameError(){
        if(courseNameIsLegal()){
            return "Class already exists";
        }
        else{
            return "Course Name must be between 1 and 50 characters";
        }
    }

    public String getReasonForSubjectError() {
        if (!courseSubjectIsLegal()) {
            return "Invalid Subject Mnemonic, must be 2-4 letters such as \"CS\", \"STS\", \"CHEM\" etc.";
        }
        return "Class already exists";
    }

    public String getReasonForCourseNumberError() {
        if (!courseNumberIsLegal()) {
            return "Invalid course number, must be a 4 digit integer";
        }
        return "Class already exists";
    }

    public boolean canCreateCourse(){
        if(everyThingIsLegal() && !classExists()){
            return true;
        }
        return false;
    }

    public void createCourse() throws SQLException {
        CoursesManager test = CoursesManager.getInstance();
        test.addCourse( "CS",3140, "Software Development Essentials");
    }


}
