package edu.virginia.sde.reviews;

public class Review {
    private String subject;
    private int number;
    private double rating;
    private String comment;
    private String timePosted;

    public Review(String subject, int number, double rating, String comment, String timePosted) {
        this.subject = subject;
        this.number = number;
        this.rating = rating;
        this.comment = comment;
        this.timePosted = timePosted;
    }

    public String getSubject() {
        return subject;
    }

    public int getNumber() {
        return number;
    }

    public double getRating() {
        return rating;
    }

    public String getComment() {
        return comment;
    }

    public String getTimePosted() {
        return timePosted;
    }
}