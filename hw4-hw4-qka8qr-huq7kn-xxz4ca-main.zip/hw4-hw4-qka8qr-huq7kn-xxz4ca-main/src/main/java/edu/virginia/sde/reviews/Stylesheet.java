package edu.virginia.sde.reviews;

import java.util.Objects;

public class Stylesheet {
    String darkMode = Objects.requireNonNull(this.getClass().getResource("/edu/virginia/sde/reviews/DarkMode.css")).toExternalForm();

    String lightMode = Objects.requireNonNull(this.getClass().getResource("/edu/virginia/sde/reviews/LightMode.css")).toExternalForm();
}
