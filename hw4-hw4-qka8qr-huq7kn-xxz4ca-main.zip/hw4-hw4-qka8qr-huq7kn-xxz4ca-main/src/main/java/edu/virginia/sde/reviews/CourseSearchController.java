package edu.virginia.sde.reviews;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.layout.HBox;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

public class CourseSearchController {

    @FXML private TextField courseName;
    @FXML private TextField courseSubject;
    @FXML private TextField courseNumber;
    @FXML private Button searchButton;
    @FXML private VBox courseResultsContainer;

    private static final CurrentSearchParameters searchParams = new CurrentSearchParameters("", "", "");

    @FXML
    public void initialize() throws SQLException {

        courseName.setText(searchParams.getCourseName());
        courseSubject.setText(searchParams.getCourseSubject());
        courseNumber.setText(searchParams.getCourseNumber());


        courseName.textProperty().addListener((obs, oldVal, newVal) -> searchParams.setCourseName(newVal));
        courseSubject.textProperty().addListener((obs, oldVal, newVal) -> searchParams.setCourseSubject(newVal));
        courseNumber.textProperty().addListener((obs, oldVal, newVal) -> searchParams.setCourseNumber(newVal));



        //TODO: replace with method like getUpdatedCourseList, where it takes the 2d array from the searching courses sql and parses them into this list of courses
        List<Course> dummyCourses = List.of(
                new Course("CS", 3140, "Software Development Essentials", 4.95),
                new Course("CHEM", 1410, "Introductory Chemistry", 3.75),
                new Course("STS", 2500, "Science and Society", null)
        );


        searchButton.setOnAction(event -> displayCourses(dummyCourses));

        displayCourses(dummyCourses);
    }

    private void displayCourses(List<Course> courses) {
        courseResultsContainer.getChildren().clear();

        if (courses.isEmpty()) {
            Label noResults = new Label("No Courses Found");
            noResults.getStyleClass().add("form-label-header");
            noResults.setTextFill(Color.WHITE);
            courseResultsContainer.getChildren().add(noResults);
            return;
        }

        for (Course course : courses) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/edu/virginia/sde/reviews/CourseBox.fxml"));
                HBox courseBox = loader.load();
                CourseBoxController CourseController = loader.getController();
                CourseController.setCourse(course);
                courseResultsContainer.getChildren().add(courseBox);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
