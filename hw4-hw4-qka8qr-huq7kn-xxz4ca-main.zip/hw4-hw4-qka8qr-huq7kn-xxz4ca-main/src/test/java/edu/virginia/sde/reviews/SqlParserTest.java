package edu.virginia.sde.reviews;

import org.junit.jupiter.api.Test;

import java.sql.SQLException;

public class SqlParserTest {

    @Test
    void testSqlParser() throws SQLException {
        //LoginManager loginManager = new LoginManager();
        //loginManager.addUser("beta", "pearAndTea");
        //DepartmentTableCreator departmentTableCreator = DepartmentTableCreator();
        //DepartmentTableCreator.createTable();
        //CourseTableCreator.createTable();
        CoursesManager coursesManager = new CoursesManager();
        coursesManager.addCourse("CS", 3130, "CSO");
        ReviewsManager reviewsManager = new ReviewsManager();
        reviewsManager.addWithoutComment("beta", 3130, 5);
        SqlParser sqlParser = new SqlParser();
        sqlParser.getCourseSpecificReviewsAsArray(3130);
    }
}
