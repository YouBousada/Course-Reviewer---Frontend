# Homework 4 - Course Review Application

## Authors
1) Youssef Bousada, qka8qr, [YouBousada]
2) Tony Aleman, huq7kn, [alemanac]
3) John Havelka, xxz4ca, [JohnnyHavelka]

## To Run

--module-path /YOUR PATH/lib --add-modules javafx.controls,javafx.fxml,    main class: edu.virginia.sde.reviews.CourseReviewsApplication,  run CourseReviewsApplication

## Contributions

List the primary contributions of each author. It is recommended to update this with your contributions after each coding session.:

### [Author 1 - Youssef Bousada]

* Created front-end of application, including all relavant classes to front end behaviors
* as a bulleted list
* each line starts with an asterisk and a space

### [Author 2 - Tony Aleman]

* Created the SQL backend
* Created some of the helper methods to integrate to the frontend

### [Author 3 - John Havelka]

* 3.3 Course Reviews Scene
*  Show the list of reviews for a given course
*  Allow users to add their own reviews/see the review they already added/edit their review.

## Issues

SQL database sqlParser has issues retrieving data from the database, at the time of submission, only user data is stored, all other data is dummy-data for the sake of testing the front end.
